Q: why the tool got blocked?

A:it's not our fault,you can fix in by doing the step below

1.

![1.click the place that circled](/assets/windef_err_sol_pic2.png)

2.

![2.click the place that circled](/assets/windef_err_sol_pic3.png)

sometime it ll' do a fast scan to the file,in normal,it ll' let u run the tool after doing ths step

Q:why i cant see the script file?

A:you need to copy it to a text file, then rename it to [FILENAME].bat,the [FILENAME] can be any string

Q:how can I know it's a offical release

A: you can do a gpg sign verify ,please refer to [this document](how-to-use.md#verify-file)