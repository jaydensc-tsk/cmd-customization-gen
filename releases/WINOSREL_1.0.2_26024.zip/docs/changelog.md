# WINOSRES_1.0.0_BETA_26201
*change*

THE FIRST VERSION OF THE GENERATION TOOLS
# WINOSREL_1.0.0_26202
*change*

the first real release with some bugs fixed
# WINOSREL_1.0.1_26203
*change*

fixed some bugs
# WINOSREL_1.0.2_26204
*change*

docs attached and fixed some bugs