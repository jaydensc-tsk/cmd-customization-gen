*this file also available in JP,CN-TRAD. and CN-SIMP.*
# WELCOME TO "[cmd-customization-gen](https://github.com/jaydensc-tsk/cmd-customization-gen)" repository
# 1 what-this-for
this is a repo for a tools that let gen a script you start a cmd with custom title bar,custom prompt and print a string of text (customable) when it start
for how it work,see [§2-how-it-work](/docs/README.md#2-how-it-work)
for how to use,see [§3-how-to-use](/docs/README.md#3-how-to-use) and [this document](/docs/how-to-use.md)
for FAQ,see [this document](/docs/FAQ.md)
# 2-how-it-work
It basicly use the `prompt`  , `title`  and `color` command in a branch file script
# 3-how-to-use 
when you open the tool,you can see thing like this

![pic](/assets/main_menu.png)

this is the main menu of the tool! at there,you can see 3 option in there:"gen script","about" and "quit",you can enterng the number before a option to enter it.

in normal,you can see hint like this in the options in the gen menu:

![pic](/assets/hint.png)

pro tips: dont forgot to enter the option 6 ("generate") to view &copy the script!
# trobleshooting
## tool-got-blocked
![pic](/assets/windef_err_sol_pic1.png)

it's not our fault,you can fix in by doing the step below

1.

![1.click the place that circled](/assets/windef_err_sol_pic2.png)

2.

![2.click the place that circled](/assets/windef_err_sol_pic3.png)

sometime it ll' do a fast scan to the file,in normal,it ll' let u run the tool after doing ths step
## script generate not properly
1. check your tool's version ,if its the newest version, open a new issue,because sometime i can miss a space or something else

2.if it not the newest version,try update it,this may fix the issue